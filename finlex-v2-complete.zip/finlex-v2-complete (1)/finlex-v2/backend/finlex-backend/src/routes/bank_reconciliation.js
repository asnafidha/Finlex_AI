const router = require('express').Router()
const pool   = require('../config/db')
const auth   = require('../middleware/auth')

router.use(auth)

// GET /api/bank-recon?company_id=xxx&account_id=xxx&from=&to=
router.get('/', async (req, res) => {
  const { company_id, account_id, from, to } = req.query
  if (!company_id) return res.status(400).json({ error: 'company_id required' })
  try {
    let q = `SELECT bs.*, je.entry_number, je.narration as je_narration
             FROM bank_statements bs
             LEFT JOIN journal_entries je ON je.id = bs.matched_je_id
             WHERE bs.company_id=$1`
    const params = [company_id]
    if (account_id) { params.push(account_id); q += ` AND bs.account_id=$${params.length}` }
    if (from)       { params.push(from);       q += ` AND bs.statement_date>=$${params.length}` }
    if (to)         { params.push(to);         q += ` AND bs.statement_date<=$${params.length}` }
    q += ' ORDER BY bs.statement_date DESC'
    const { rows: statements } = await pool.query(q, params)

    // Summary
    const unmatched  = statements.filter(s => !s.matched)
    const matched    = statements.filter(s => s.matched)
    const total_unmatched_debit  = unmatched.filter(s => s.debit_amount > 0).reduce((s,r) => s + parseFloat(r.debit_amount), 0)
    const total_unmatched_credit = unmatched.filter(s => s.credit_amount > 0).reduce((s,r) => s + parseFloat(r.credit_amount), 0)

    res.json({ statements, summary: { total: statements.length, matched: matched.length, unmatched: unmatched.length, total_unmatched_debit, total_unmatched_credit } })
  } catch (err) { res.status(500).json({ error: err.message }) }
})

// POST /api/bank-recon/upload — bulk upload bank statement lines
router.post('/upload', async (req, res) => {
  const { company_id, account_id, lines } = req.body
  if (!company_id || !account_id || !lines?.length)
    return res.status(400).json({ error: 'company_id, account_id, lines required' })

  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    let inserted = 0

    for (const line of lines) {
      const debit  = parseFloat(line.debit  || 0)
      const credit = parseFloat(line.credit || 0)
      if (debit < 0 || credit < 0) continue
      if (debit === 0 && credit === 0) continue
      await client.query(
        `INSERT INTO bank_statements(company_id,account_id,statement_date,description,debit_amount,credit_amount,balance,reference)
         VALUES($1,$2,$3,$4,$5,$6,$7,$8)
         ON CONFLICT DO NOTHING`,
        [company_id, account_id, line.date, line.description || '', debit, credit, parseFloat(line.balance||0), line.reference||null]
      )
      inserted++
    }

    // Auto-match: try to match against journal entries by amount + date proximity (±3 days)
    const { rows: unmatched } = await client.query(
      `SELECT * FROM bank_statements WHERE company_id=$1 AND account_id=$2 AND matched=false`, [company_id, account_id]
    )

    let autoMatched = 0
    for (const stmt of unmatched) {
      const amt = parseFloat(stmt.debit_amount) > 0 ? parseFloat(stmt.debit_amount) : parseFloat(stmt.credit_amount)
      const col = parseFloat(stmt.debit_amount) > 0 ? 'jel.credit_amount' : 'jel.debit_amount'

      const { rows: jeMatches } = await client.query(
        `SELECT je.id FROM journal_entries je
         JOIN journal_entry_lines jel ON jel.journal_entry_id=je.id
         JOIN accounts a ON a.id=jel.account_id
         WHERE je.company_id=$1 AND a.id=$2
           AND ${col}=$3
           AND je.entry_date BETWEEN $4::date-3 AND $4::date+3
         ORDER BY ABS(EXTRACT(EPOCH FROM (je.entry_date - $4::date))) ASC LIMIT 1`,
        [company_id, account_id, amt, stmt.statement_date]
      )

      if (jeMatches.length > 0) {
        await client.query(
          `UPDATE bank_statements SET matched=true, matched_je_id=$1 WHERE id=$2`,
          [jeMatches[0].id, stmt.id]
        )
        autoMatched++
      }
    }

    await client.query('COMMIT')
    res.json({ message: 'Bank statement uploaded', inserted, auto_matched: autoMatched })
  } catch (err) {
    await client.query('ROLLBACK')
    res.status(500).json({ error: err.message })
  } finally { client.release() }
})

// PATCH /api/bank-recon/:id/match — manually match a statement line to a JE
router.patch('/:id/match', async (req, res) => {
  const { journal_entry_id } = req.body
  try {
    const { rows } = await pool.query(
      `UPDATE bank_statements SET matched=true, matched_je_id=$1 WHERE id=$2 RETURNING *`,
      [journal_entry_id, req.params.id]
    )
    if (!rows.length) return res.status(404).json({ error: 'Statement line not found' })
    res.json(rows[0])
  } catch (err) { res.status(500).json({ error: err.message }) }
})

// PATCH /api/bank-recon/:id/unmatch
router.patch('/:id/unmatch', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `UPDATE bank_statements SET matched=false, matched_je_id=NULL WHERE id=$1 RETURNING *`,
      [req.params.id]
    )
    if (!rows.length) return res.status(404).json({ error: 'Statement line not found' })
    res.json(rows[0])
  } catch (err) { res.status(500).json({ error: err.message }) }
})

// DELETE /api/bank-recon/:id
router.delete('/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM bank_statements WHERE id=$1', [req.params.id])
    res.json({ message: 'Deleted' })
  } catch (err) { res.status(500).json({ error: err.message }) }
})

module.exports = router

// GET /api/bank-recon/summary
router.get("/summary", async (req, res) => {
  const { company_id } = req.query;
  if (!company_id) return res.status(400).json({ error: "company_id required" });
  try {
    const { rows } = await pool.query(
      `SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN matched THEN 1 ELSE 0 END) as matched,
        SUM(CASE WHEN NOT matched THEN 1 ELSE 0 END) as unmatched,
        SUM(CASE WHEN debit_amount > 0 AND NOT matched THEN debit_amount ELSE 0 END) as unmatched_debit,
        SUM(CASE WHEN credit_amount > 0 AND NOT matched THEN credit_amount ELSE 0 END) as unmatched_credit
       FROM bank_statements WHERE company_id = $1`,
      [company_id]
    );
    res.json(rows[0] || { total: 0, matched: 0, unmatched: 0, unmatched_debit: 0, unmatched_credit: 0 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

