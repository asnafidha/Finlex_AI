import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { payroll } from '../services/api';

export default function PayrollPage() {
  const { company } = useAuth();
  const [entries, setEntries] = useState([]);
  const [summary, setSummary] = useState({});
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    if (company?.id) loadData();
  }, [company]);

  const loadData = async () => {
    setLoading(true);
    try {
      const data = await payrollAPI.list(company.id);
      // Ensure data.entries is an array
      const entriesArray = Array.isArray(data.entries) ? data.entries : [];
      setEntries(entriesArray);
      setSummary(data.summary || { total_gross: 0, total_net: 0, total_tds: 0, total_pf: 0, count: entriesArray.length });
    } catch (err) {
      console.error('Payroll load error:', err);
      setEntries([]);
      setSummary({ total_gross: 0, total_net: 0, total_tds: 0, total_pf: 0, count: 0 });
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div style={{ padding: 40, textAlign: 'center' }}>Loading payroll data...</div>;

  return (
    <div style={{ animation: 'fadeUp 0.5s ease' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700, color: 'var(--navy)', marginBottom: 4 }}>Payroll (PF/ESIC)</h1>
          <p style={{ color: 'var(--gray-600)', fontSize: 15 }}>Employee salary processing with auto PF/ESIC calculation</p>
        </div>
        <button onClick={() => setShowForm(true)} style={{
          background: 'linear-gradient(135deg, #C9A84C, #e2c06e)',
          border: 'none', padding: '10px 20px', borderRadius: 10,
          color: 'var(--navy)', fontWeight: 700, cursor: 'pointer'
        }}>+ Add Employee Salary</button>
      </div>

      {/* Summary Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
        <div style={{ background: '#ecfdf5', padding: 16, borderRadius: 12 }}>
          <div style={{ fontSize: 12, color: '#065f46' }}>Total Gross Salary</div>
          <div style={{ fontSize: 24, fontWeight: 700, color: '#065f46' }}>₹{(summary.total_gross || 0).toLocaleString()}</div>
        </div>
        <div style={{ background: '#dbeafe', padding: 16, borderRadius: 12 }}>
          <div style={{ fontSize: 12, color: '#1e40af' }}>Total TDS Deducted</div>
          <div style={{ fontSize: 24, fontWeight: 700, color: '#1e40af' }}>₹{(summary.total_tds || 0).toLocaleString()}</div>
        </div>
        <div style={{ background: '#fef3c7', padding: 16, borderRadius: 12 }}>
          <div style={{ fontSize: 12, color: '#92400e' }}>Total PF (Emp+Er)</div>
          <div style={{ fontSize: 24, fontWeight: 700, color: '#92400e' }}>₹{(summary.total_pf || 0).toLocaleString()}</div>
        </div>
        <div style={{ background: '#f3e8ff', padding: 16, borderRadius: 12 }}>
          <div style={{ fontSize: 12, color: '#6b21a5' }}>Total Employees</div>
          <div style={{ fontSize: 24, fontWeight: 700, color: '#6b21a5' }}>{summary.count || 0}</div>
        </div>
      </div>

      {/* Entries Table */}
      {entries.length === 0 ? (
        <div style={{ textAlign: 'center', padding: 60, background: 'var(--gray-100)', borderRadius: 16 }}>
          <p>No payroll entries yet. Click "Add Employee Salary" to start.</p>
        </div>
      ) : (
        <div style={{ background: 'white', borderRadius: 16, border: '1px solid var(--gray-200)', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--navy)' }}>
                <th style={{ padding: 12, textAlign: 'left', color: 'var(--gold)' }}>Employee</th>
                <th style={{ padding: 12, textAlign: 'left', color: 'var(--gold)' }}>Month</th>
                <th style={{ padding: 12, textAlign: 'right', color: 'var(--gold)' }}>Gross</th>
                <th style={{ padding: 12, textAlign: 'right', color: 'var(--gold)' }}>PF</th>
                <th style={{ padding: 12, textAlign: 'right', color: 'var(--gold)' }}>ESIC</th>
                <th style={{ padding: 12, textAlign: 'right', color: 'var(--gold)' }}>TDS</th>
                <th style={{ padding: 12, textAlign: 'right', color: 'var(--gold)' }}>Net Salary</th>
              </tr>
            </thead>
            <tbody>
              {entries.map((entry, i) => (
                <tr key={entry.id || i} style={{ borderBottom: '1px solid var(--gray-200)', background: i % 2 === 0 ? 'white' : 'var(--gray-100)' }}>
                  <td style={{ padding: 12 }}>{entry.employee_name}</td>
                  <td style={{ padding: 12 }}>{entry.month}/{entry.year}</td>
                  <td style={{ padding: 12, textAlign: 'right' }}>₹{(entry.gross_salary || 0).toLocaleString()}</td>
                  <td style={{ padding: 12, textAlign: 'right' }}>₹{((entry.pf_employee || 0) + (entry.pf_employer || 0)).toLocaleString()}</td>
                  <td style={{ padding: 12, textAlign: 'right' }}>₹{((entry.esic_employee || 0) + (entry.esic_employer || 0)).toLocaleString()}</td>
                  <td style={{ padding: 12, textAlign: 'right' }}>₹{(entry.tds_amount || 0).toLocaleString()}</td>
                  <td style={{ padding: 12, textAlign: 'right', fontWeight: 700 }}>₹{(entry.net_salary || 0).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showForm && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ background: 'white', padding: 24, borderRadius: 16, width: 500 }}>
            <h2>Add Employee Salary</h2>
            <p style={{ fontSize: 13, color: '#666' }}>Form coming soon. Use backend API to add entries.</p>
            <button onClick={() => setShowForm(false)} style={{ marginTop: 16, padding: '8px 16px', background: '#C9A84C', border: 'none', borderRadius: 8, cursor: 'pointer' }}>Close</button>
          </div>
        </div>
      )}
    </div>
  );
}
