const router = require('express').Router()
const pool   = require('../config/db')
const auth   = require('../middleware/auth')

router.use(auth)

// GET /api/depreciation/assets?company_id=xxx
router.get('/assets', async (req, res) => {
  const { company_id } = req.query
  if (!company_id) return res.status(400).json({ error: 'company_id required' })
  try {
    const { rows } = await pool.query(
      'SELECT fa.*, a.name as account_name FROM fixed_assets fa LEFT JOIN accounts a ON a.id=fa.account_id WHERE fa.company_id=$1 ORDER BY fa.asset_name',
      [company_id]
    )
    res.json(rows)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

// POST /api/depreciation/assets
router.post('/assets', async (req, res) => {
  const { company_id, asset_name, asset_code, category, purchase_date, cost_price, salvage_value, useful_life_years, method, wdv_rate, account_id } = req.body
  if (!company_id || !asset_name || !purchase_date || !cost_price)
    return res.status(400).json({ error: 'company_id, asset_name, purchase_date, cost_price required' })

  try {
    const { rows } = await pool.query(
      `INSERT INTO fixed_assets(company_id,asset_name,asset_code,category,purchase_date,cost_price,salvage_value,useful_life_years,method,wdv_rate,current_wdv,account_id,created_by)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,
      [company_id, asset_name, asset_code||null, category||null, purchase_date,
       parseFloat(cost_price), parseFloat(salvage_value||0),
       parseInt(useful_life_years||5), method||'SLM', parseFloat(wdv_rate||20),
       parseFloat(cost_price), account_id||null, req.user.id]
    )
    res.status(201).json(rows[0])
  } catch (err) { res.status(500).json({ error: err.message }) }
})

// POST /api/depreciation/compute — compute & post depreciation for a financial year
router.post('/compute', async (req, res) => {
  const { company_id, financial_year, post_journal } = req.body
  if (!company_id || !financial_year)
    return res.status(400).json({ error: 'company_id and financial_year required' })

  try {
    const { rows: assets } = await pool.query(
      `SELECT * FROM fixed_assets WHERE company_id=$1 AND is_active=true`, [company_id]
    )
    if (!assets.length) return res.json({ message: 'No active assets found', entries: [] })

    const results = []
    const client = await pool.connect()
    try {
      await client.query('BEGIN')

      const getAcc = async (code) => {
        const r = await client.query('SELECT id FROM accounts WHERE company_id=$1 AND code=$2', [company_id, code])
        return r.rows[0]?.id
      }
      const deprExp = await getAcc('5109')  // Depreciation expense
      const accumDepr = await getAcc('1105') // Accumulated Depreciation

      for (const asset of assets) {
        // Check if already computed for this FY
        const { rows: existing } = await client.query(
          'SELECT id FROM depreciation_entries WHERE asset_id=$1 AND financial_year=$2', [asset.id, financial_year]
        )
        if (existing.length > 0) {
          results.push({ asset_name: asset.asset_name, status: 'already_computed', financial_year })
          continue
        }

        const opening_wdv = parseFloat(asset.current_wdv || asset.cost_price)
        let depreciation = 0

        if (asset.method === 'SLM') {
          // Straight Line Method: (Cost - Salvage) / Useful Life
          const depreciable = parseFloat(asset.cost_price) - parseFloat(asset.salvage_value || 0)
          depreciation = depreciable / parseInt(asset.useful_life_years || 5)
        } else {
          // WDV: opening_wdv * rate%
          depreciation = opening_wdv * parseFloat(asset.wdv_rate || 20) / 100
        }

        depreciation = Math.min(depreciation, Math.max(0, opening_wdv - parseFloat(asset.salvage_value || 0)))
        const closing_wdv = opening_wdv - depreciation

        if (depreciation <= 0) {
          results.push({ asset_name: asset.asset_name, status: 'fully_depreciated', closing_wdv })
          continue
        }

        // Post journal if requested
        let jeId = null
        if (post_journal !== false) {
          const { rows: countRows } = await client.query('SELECT COUNT(*) FROM journal_entries WHERE company_id=$1', [company_id])
          const entryNum = `JE-${String(parseInt(countRows[0].count) + 1).padStart(4, '0')}`
          const je = await client.query(
            `INSERT INTO journal_entries(company_id,entry_number,entry_date,reference_type,narration,is_posted,created_by)
             VALUES($1,$2,$3,'depreciation',$4,true,$5) RETURNING id`,
            [company_id, entryNum, `${financial_year.split('-')[1]}-03-31`,
             `Depreciation — ${asset.asset_name} — FY ${financial_year} (${asset.method})`, req.user.id]
          )
          jeId = je.rows[0].id
          if (deprExp)  await client.query(`INSERT INTO journal_entry_lines(journal_entry_id,account_id,debit_amount,credit_amount,narration) VALUES($1,$2,$3,0,$4)`, [jeId, deprExp, depreciation, `Depreciation on ${asset.asset_name}`])
          if (accumDepr)await client.query(`INSERT INTO journal_entry_lines(journal_entry_id,account_id,debit_amount,credit_amount,narration) VALUES($1,$2,0,$3,$4)`, [jeId, accumDepr, depreciation, `Accumulated depreciation — ${asset.asset_name}`])
        }

        // Record depreciation entry
        await client.query(
          `INSERT INTO depreciation_entries(company_id,asset_id,financial_year,opening_wdv,depreciation,closing_wdv,method,journal_entry_id,created_by)
           VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
          [company_id, asset.id, financial_year, opening_wdv, depreciation, closing_wdv, asset.method, jeId, req.user.id]
        )

        // Update asset's current WDV
        await client.query('UPDATE fixed_assets SET current_wdv=$1 WHERE id=$2', [closing_wdv, asset.id])

        results.push({ asset_name: asset.asset_name, method: asset.method, opening_wdv, depreciation: Math.round(depreciation * 100) / 100, closing_wdv: Math.round(closing_wdv * 100) / 100, status: 'posted' })
      }

      await client.query('COMMIT')
      res.json({ financial_year, entries: results, total_depreciation: results.reduce((s,r) => s + (r.depreciation||0), 0) })
    } catch (err) {
      await client.query('ROLLBACK')
      throw err
    } finally { client.release() }
  } catch (err) { res.status(500).json({ error: err.message }) }
})

// GET /api/depreciation/schedule?company_id=xxx
router.get('/schedule', async (req, res) => {
  const { company_id } = req.query
  if (!company_id) return res.status(400).json({ error: 'company_id required' })
  try {
    const { rows } = await pool.query(
      `SELECT de.*, fa.asset_name, fa.method, fa.cost_price
       FROM depreciation_entries de
       JOIN fixed_assets fa ON fa.id=de.asset_id
       WHERE de.company_id=$1 ORDER BY fa.asset_name, de.financial_year`,
      [company_id]
    )
    res.json(rows)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

module.exports = router

// Alias for frontend compatibility
router.get("/schedules", async (req, res) => {
  req.url = "/schedule";
  return router.handle(req, res);
});

