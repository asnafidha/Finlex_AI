const router = require('express').Router()
const pool   = require('../config/db')
const auth   = require('../middleware/auth')

router.use(auth)

// GET /api/opening-balances?company_id=xxx — current opening balances
router.get('/', async (req, res) => {
  const { company_id } = req.query
  if (!company_id) return res.status(400).json({ error: 'company_id required' })
  try {
    const { rows } = await pool.query(
      `SELECT a.id, a.code, a.name, a.type, a.nature, a.opening_balance, ag.name as group_name
       FROM accounts a
       LEFT JOIN account_groups ag ON ag.id = a.group_id
       WHERE a.company_id=$1 ORDER BY a.code`,
      [company_id]
    )
    const total_debit  = rows.filter(r => r.nature === 'debit').reduce((s,r) => s + parseFloat(r.opening_balance||0), 0)
    const total_credit = rows.filter(r => r.nature === 'credit').reduce((s,r) => s + parseFloat(r.opening_balance||0), 0)
    res.json({ accounts: rows, total_debit, total_credit, is_balanced: Math.abs(total_debit - total_credit) < 0.01 })
  } catch (err) { res.status(500).json({ error: err.message }) }
})

// POST /api/opening-balances/import — bulk import
// Body: { company_id, financial_year, balances: [{ account_id, amount, nature }] }
router.post('/import', async (req, res) => {
  const { company_id, financial_year, balances } = req.body
  if (!company_id || !balances?.length)
    return res.status(400).json({ error: 'company_id and balances array required' })

  // Validate balance: total debit entries must equal total credit entries
  const totalDebit  = balances.filter(b => b.nature === 'debit').reduce((s,b) => s + parseFloat(b.amount||0), 0)
  const totalCredit = balances.filter(b => b.nature === 'credit').reduce((s,b) => s + parseFloat(b.amount||0), 0)
  if (Math.abs(totalDebit - totalCredit) > 0.01)
    return res.status(400).json({
      error: `Opening balances don't tally. Debit total: ₹${totalDebit.toFixed(2)}, Credit total: ₹${totalCredit.toFixed(2)}, Difference: ₹${Math.abs(totalDebit-totalCredit).toFixed(2)}`
    })

  const client = await pool.connect()
  try {
    await client.query('BEGIN')

    for (const b of balances) {
      const amt = parseFloat(b.amount || 0)
      await client.query(
        `UPDATE accounts SET opening_balance=$1 WHERE id=$2 AND company_id=$3`,
        [amt, b.account_id, company_id]
      )
    }

    const { rows: [log] } = await client.query(
      `INSERT INTO opening_balance_imports(company_id,import_date,financial_year,total_debit,total_credit,is_balanced,imported_by)
       VALUES($1,CURRENT_DATE,$2,$3,$4,true,$5) RETURNING id`,
      [company_id, financial_year || '2024-25', totalDebit, totalCredit, req.user.id]
    )

    await client.query(
      `INSERT INTO audit_log(company_id,user_id,action,table_name,record_id,new_values) VALUES($1,$2,'OPENING_BALANCE_IMPORTED','accounts',NULL,$3)`,
      [company_id, req.user.id, JSON.stringify({ accounts_updated: balances.length, total_debit: totalDebit, total_credit: totalCredit, import_id: log.id })]
    )

    await client.query('COMMIT')
    res.json({ message: `Opening balances imported for ${balances.length} accounts`, import_id: log.id, total_debit: totalDebit, total_credit: totalCredit })
  } catch (err) {
    await client.query('ROLLBACK')
    res.status(500).json({ error: err.message })
  } finally { client.release() }
})

// GET /api/opening-balances/template — downloadable CSV template
router.get('/template', async (req, res) => {
  const { company_id } = req.query
  if (!company_id) return res.status(400).json({ error: 'company_id required' })
  try {
    const { rows } = await pool.query(
      'SELECT id, code, name, type, nature FROM accounts WHERE company_id=$1 ORDER BY code', [company_id]
    )
    let csv = 'account_id,code,account_name,type,nature,opening_balance\n'
    rows.forEach(r => {
      csv += `${r.id},${r.code},"${r.name}",${r.type},${r.nature},0.00\n`
    })
    res.setHeader('Content-Type', 'text/csv')
    res.setHeader('Content-Disposition', `attachment; filename="opening_balances_template.csv"`)
    res.send(csv)
  } catch (err) { res.status(500).json({ error: err.message }) }
})

module.exports = router
