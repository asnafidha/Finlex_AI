const pool = require('../config/db')
module.exports = async (req, res, next) => {
  const company_id = req.body?.company_id || req.query?.company_id || req.params?.company_id
  if (!company_id) return next()
  try {
    const { rows } = await pool.query(
      'SELECT 1 FROM ca_company_access WHERE ca_id=$1 AND company_id=$2',
      [req.user.id, company_id]
    )
    if (!rows.length) return res.status(403).json({ error: 'Access denied to this company' })
    next()
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
}
